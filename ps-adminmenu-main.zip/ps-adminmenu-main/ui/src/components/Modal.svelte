<div class="fixed top-0 left-0 bottom-0 right-0 flex items-center justify-center bg-black bg-opacity-75">
    <div class=" bg-tertiary rounded-[0.5vh] flex flex-col px-[2vh] py-[1.5vh] gap-[0.8vh]">
        <slot></slot>
    </div>
</div>